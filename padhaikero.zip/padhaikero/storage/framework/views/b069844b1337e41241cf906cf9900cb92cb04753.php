<a href="/">
<img style="height: 80px;" src="<?php echo e(asset('images-website/logo-t.png')); ?>" alt="">
</a>
<?php /**PATH D:\Laravel-Project\padhaikero\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>