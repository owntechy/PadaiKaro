<header id="header_part" class="fullwidth">
    <div id="header">
        <div class="container">
            <div class="utf_left_side">
                <div id="logo"> <a href="/"><img style="height: 80px;" src="<?php echo e(asset('images-website/logo-t.png')); ?>" alt=""></a> </div>
                <div class="mmenu-trigger">
                    <button class="hamburger utfbutton_collapse" type="button">
                        <span class="utf_inner_button_box">
                            <span class="utf_inner_section"></span>
                        </span>
                    </button>
                </div>
                <nav id="navigation" class="style_one">
                    <ul id="responsive">
                        <li><a class="current" href="#">Home</a> </li>
                        <li><a href="#">Find college</a> </li>
                        <li><a href="#">City Colege</a></li>
                        <li><a href="#">Blog</a> </li>
                        <li><a href="#">About Us</a>
                        </li>
                    </ul>
                </nav>
                <div class="clearfix"></div>
            </div>
            <div class="utf_right_side">
                <div class="header_widget"> <a href="#" class="button border sign-in popup-with-zoom-anim"><i class="fa fa-search"></i>Find College</a></div>
            </div>
            
        </div>
    </div>
</header>
<div class="clearfix"></div><?php /**PATH D:\Laravel-Project\padhaikero\resources\views/Layouts/components/header.blade.php ENDPATH**/ ?>