<div class="slider">
    <div class="wrapper">1</div>
    <div class="wrapper">2</div>
    <div class="wrapper">3</div>
    <div class="wrapper">4</div>
    <div class="wrapper">5</div>
    <div class="wrapper">6</div>
    <div class="wrapper">7</div>
    <div class="wrapper">8</div>
    <div class="wrapper">9</div>
    <div class="wrapper">10</div>
    <div class="wrapper">11</div>
    <div class="wrapper">12</div>
</div>