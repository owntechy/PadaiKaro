<a href="/">
<img style="height: 80px;" src="{{asset('images-website/logo-t.png')}}" alt="">
</a>
